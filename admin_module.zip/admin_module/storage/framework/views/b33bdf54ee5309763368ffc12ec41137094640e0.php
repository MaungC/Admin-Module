<?php ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Role Info</div>

                    <div class="panel-body">


                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Name</label>
                            <?php echo e($role->display_name); ?>

                        </div>


                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Description</label>
                            <?php echo e($role->description); ?>

                        </div>


                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Permissions</label>
                            <?php if(!empty($permissions)): ?>
                                <div class="col-md-8 control-label">
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="label label-success" style="float: left; margin-right: 5px"><?php echo e($permission->display_name); ?></label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>